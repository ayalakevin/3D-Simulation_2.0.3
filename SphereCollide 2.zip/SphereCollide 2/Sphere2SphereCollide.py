import math
def main(S1,S2):
    S1Speed = math.sqrt((S1.speedx**2)+(S1.speedy**2)+(S1.speedz**2))
    XDiff = -(S1.x-S2.x)
    YDiff = -(S1.y-S2.y)
    ZDiff = -(S1.z-S2.z)
    ElevationAngle = math.atan(YDiff/(math.sqrt((XDiff**2)+(ZDiff**2))))
    if XDiff != 0 and ZDiff != 0:
        if XDiff > 0:
            if ZDiff > 0:   Angle = math.atan(ZDiff/XDiff)
            elif ZDiff < 0: Angle = math.atan(ZDiff/XDiff)
        elif XDiff < 0:
            if ZDiff > 0:   Angle =  3.1415926536 + math.atan(ZDiff/XDiff)
            elif ZDiff < 0: Angle = -3.1415926536 + math.atan(ZDiff/XDiff)
        XSpeed = -S1Speed*math.cos(Angle)*math.cos(ElevationAngle)
        YSpeed = -S1Speed*math.sin(ElevationAngle)
        ZSpeed = -S1Speed*math.sin(Angle)*math.cos(ElevationAngle)
    else:
        if XDiff == 0 and ZDiff == 0:
            Angle = 0
        if XDiff == 0 and ZDiff != 0:
            if ZDiff > 0:   Angle = -1.5707963268
            else:           Angle =  1.5707963268
        if XDiff != 0 and ZDiff == 0:
            if XDiff < 0:   Angle =  0.0
            else:           Angle =  3.1415926536
        XSpeed = S1Speed*math.cos(Angle)*math.cos(ElevationAngle)
        YSpeed = S1Speed*math.sin(ElevationAngle)
        ZSpeed = S1Speed*math.sin(Angle)*math.cos(ElevationAngle)
    S1.speedx = XSpeed
    S1.speedy = YSpeed
    S1.speedz = ZSpeed
