from OpenGL.GL import *
from OpenGL.GLU import *
import os, sys, math, random
import pygame
from pygame.locals import *
pygame.init()
def main(CameraPos, CameraRotate, KeyPress, ViewMode):

    keystate = pygame.key.get_pressed()
    mrel = pygame.mouse.get_rel()
    mpress = pygame.mouse.get_pressed()

    for event in pygame.event.get():
        if event.type == QUIT or keystate[K_ESCAPE]:
            pygame.quit(); sys.exit()
        elif event.type == MOUSEBUTTONDOWN:
            ScrollSpeed = 5
            if event.button == 4: #Scroll In
                CameraPos[1] += ScrollSpeed*math.sin(math.radians(CameraRotate[1]))
                CameraPos[2] -= ScrollSpeed*math.cos(math.radians(CameraRotate[0]))*math.cos(math.radians(CameraRotate[1]))
                CameraPos[0] += ScrollSpeed*math.sin(math.radians(CameraRotate[0]))*math.cos(math.radians(CameraRotate[1]))
            elif event.button == 5: #Scroll Out
                CameraPos[1] -= ScrollSpeed*math.sin(math.radians(CameraRotate[1]))
                CameraPos[2] += ScrollSpeed*math.cos(math.radians(CameraRotate[0]))*math.cos(math.radians(CameraRotate[1]))
                CameraPos[0] -= ScrollSpeed*math.sin(math.radians(CameraRotate[0]))*math.cos(math.radians(CameraRotate[1]))

    if mpress[0]:
        Angle = math.radians(-CameraRotate[0])
        Speed = 0.1*(CameraPos[1]/50.0)
        CameraPos[0] -= (Speed*math.cos(Angle)*mrel[0])
        CameraPos[2] -= (Speed*math.sin(Angle)*-mrel[0])
        CameraPos[0] -= (Speed*math.sin(Angle)*mrel[1])
        CameraPos[2] -= (Speed*math.cos(Angle)*mrel[1])
    if mpress[2]:
        CameraRotate[0] -= 0.1*mrel[0]
        CameraRotate[1] += 0.1*mrel[1]
    if keystate[K_v]:
        CameraPos = [20,20,20]
        CameraRotate = [-45,-30]
        ViewMode = 'Fill'
    if keystate[K_F1]:
        if not KeyPress[0]:
            if ViewMode == 'Fill': glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); ViewMode = 'Line'
            elif ViewMode == 'Line': glPolygonMode(GL_FRONT_AND_BACK, GL_POINT); ViewMode = 'Point'
            elif ViewMode == 'Point': glPolygonMode(GL_FRONT_AND_BACK, GL_FILL); ViewMode = 'Fill'
            KeyPress[0] = True
    if not keystate[K_F1]: KeyPress[0] = glPolygonMode(GL_FRONT_AND_BACK, GL_FILL); ViewMode = 'Fill'
    #glPolygonMode(GL_FRONT_AND_BACK, GL_LINE); ViewMode = 'Line'
                                        #False
    return CameraPos, CameraRotate, KeyPress, ViewMode   
