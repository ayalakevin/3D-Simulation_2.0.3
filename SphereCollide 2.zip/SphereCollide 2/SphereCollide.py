from OpenGL.GL import *
from OpenGL.GLU import *
import os, sys, math, random
import pygame
from pygame.locals import *
if sys.platform == 'win32' or sys.platform == 'win64':
    os.environ['SDL_VIDEO_CENTERED'] = '1'
import GL, Objects, ModuleGetInput, Sphere2SphereCollide

pygame.init()

Screen = (800,600)
#pygame.display.set_caption('3D Sphere Collisions - Ian Mallett - 2008')
pygame.display.set_mode(Screen,OPENGL|DOUBLEBUF)
GL.resize(800,600)
GL.init()

Spheres = []
class Sphere:
    def __init__(self):
        self.radius = random.choice([.25, .30, .50, .75])
                                    #0.25 OG
        self.x = random.uniform(self.radius, 20-self.radius)
        self.y = random.uniform(self.radius, 20-self.radius)
        self.z = random.uniform(self.radius, 20-self.radius)
        self.speedx = 0.1*(random.random()-0.5)
        self.speedy = 0.1*(random.random()-0.5)
        self.speedz = 0.1*(random.random()-0.5)
        #Sphere.RotateRate = random.choice([-4,-3,-2,-1,1,2,3,4])
        self.rotate = [0.0,0.0]
for x in range(10):
    Spheres.append(Sphere())

CameraPos = [40,45,40]
CameraRotate = [-45,-45]
ViewMode = 'Fill'

KeyPress = [False]

dlWorld, dlSpheres, dlFakeshadow = Objects.main()

def Move():
    for Sphere in Spheres:
        Sphere.x += Sphere.speedx/10
        Sphere.y += Sphere.speedy/10
        Sphere.z += Sphere.speedz/10
        #Sphere.rotate[0] += Sphere.RotateRate
        #Sphere.rotate[1] += 2*Sphere.RotateRate
        #if Sphere.rotate[0] == 360:  Sphere.rotate[0] = 0
        #if Sphere.rotate[1] == 360:  Sphere.rotate[1] = 0

def CollisionDetect():
    for Sphere in Spheres:
        if Sphere.x < Sphere.radius:  Sphere.speedx *= -1                                 
        if Sphere.y < Sphere.radius:  Sphere.speedy *= -1
        if Sphere.z < Sphere.radius:  Sphere.speedz *= -1
        if Sphere.x > 20-Sphere.radius:  Sphere.speedx *= -1
        if Sphere.y > 20-Sphere.radius:  Sphere.speedy *= -1
        if Sphere.z > 20-Sphere.radius:  Sphere.speedz *= -1
    for S1 in Spheres:
        for S2 in Spheres:
            if S1 != S2:
                Distance = math.sqrt(  ((S1.x-S2.x)**2)  +  ((S1.y-S2.y)**2)  +  ((S1.z-S2.z)**2)  )
                if Distance <= (S1.radius + S2.radius):
                    Sphere2SphereCollide.main(S1,S2)
                elif Distance <= (S1.radius + S2.radius) + 1:
                    Sphere2SphereCollide.main(S1,S2)
                elif Distance <= (S1.radius + S2.radius) +2:
                    Sphere2SphereCollide.main(S1,S2)
                    
#wall boundaries
                            
    for Sphere in Spheres:
        if Sphere.x < Sphere.radius:
            Sphere.x = 20 + Sphere.radius
        if Sphere.y < Sphere.radius:
            Sphere.y = 20 + Sphere.radius
        if Sphere.z < Sphere.radius:
            Sphere.z = 20 + Sphere.radius
        if Sphere.x > 20 - Sphere.radius:
            Sphere.x = 20 - Sphere.radius
        if Sphere.y > 20 - Sphere.radius:
            Sphere.y = 20 - Sphere.radius
        if Sphere.z > 20 - Sphere.radius:
            Sphere.z = 20 - Sphere.radius
        
def Draw():
    #Clear
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)
    glLoadIdentity()
    #Camera Position/Orient
    glRotatef(-CameraRotate[1],1,0,0)
    glRotatef( CameraRotate[0],0,1,0)
    glTranslatef(-CameraPos[0],-CameraPos[1],-CameraPos[2])
    #World
    glCallList(dlWorld)
    #Spheres
    SphereIndex = 0
    for Sphere in Spheres:
        SphereSize = Sphere.radius
        glPushMatrix()
        glTranslatef(Sphere.x, 0.01, Sphere.z)
        glScalef(SphereSize, SphereSize, SphereSize)
        glCallList(dlFakeshadow)
        glPopMatrix()
        glPushMatrix()
        glTranslatef(Sphere.x, Sphere.y, Sphere.z)
        glScalef(SphereSize, SphereSize, SphereSize)
        #glRotatef(Sphere.rotate[0],0,1,0)
        #glRotatef(Sphere.rotate[1],1,0,0)
        glCallList(dlSpheres[SphereIndex])
        glPopMatrix()
        SphereIndex += 1
    #Flip
    pygame.display.flip()
def GetInput():
    global CameraPos, CameraRotate, KeyPress, ViewMode
    CameraPos, CameraRotate, KeyPress, ViewMode = ModuleGetInput.main(CameraPos, CameraRotate, KeyPress, ViewMode)
def main():
    while True:
        GetInput()
        Move()
        CollisionDetect()
        Draw()
if __name__ == '__main__': main()


#update position
#function to calculate new position





#notes 2/27/19
#excel sheet edit make phase 2 go through battery chargers and then requests










