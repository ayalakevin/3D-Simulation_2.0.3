from OpenGL.GL import *
from OpenGL.GLU import *
import pygame
def main():
    textures = glGenTextures(30)

    Surface = pygame.image.load('Data/Grid.png')
    Data = pygame.image.tostring(Surface, "RGBA", 1)
    glBindTexture(GL_TEXTURE_2D, textures[0])
    glTexImage2D( GL_TEXTURE_2D, 0, GL_RGBA, Surface.get_width(), Surface.get_height(), 0,
                  GL_RGBA, GL_UNSIGNED_BYTE, Data )
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)

    Surface = pygame.image.load('Data/FakeShadow.png')
    Data = pygame.image.tostring(Surface, "RGBA", 1)
    glBindTexture(GL_TEXTURE_2D, textures[1])
    glTexImage2D( GL_TEXTURE_2D, 0, GL_RGBA, Surface.get_width(), Surface.get_height(), 0,
                  GL_RGBA, GL_UNSIGNED_BYTE, Data )
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
    glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)

    for number in range(15):
        Surface = pygame.image.load('Data/Ball'+str(number+1)+'.jpg')
        Data = pygame.image.tostring(Surface, "RGBA", 1)
        glBindTexture(GL_TEXTURE_2D, textures[2+number])
        glTexImage2D( GL_TEXTURE_2D, 0, GL_RGBA, Surface.get_width(), Surface.get_height(), 0,
                      GL_RGBA, GL_UNSIGNED_BYTE, Data )
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST)
        glTexParameterf(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST)

    dlWorld = glGenLists(1)
    glNewList(dlWorld, GL_COMPILE)
    glEnable(GL_TEXTURE_2D)
    glBindTexture(GL_TEXTURE_2D, textures[0])
    #Draw Box
    glBegin(GL_QUADS)
    glTexCoord2i(0,0); glVertex3i(0 ,0 ,0 )
    glTexCoord2i(1,0); glVertex3i(20,0 ,0 )
    glTexCoord2i(1,1); glVertex3i(20,0 ,20)
    glTexCoord2i(0,1); glVertex3i(0 ,0 ,20)

    glTexCoord2i(0,0); glVertex3i(0 ,20,0 )
    glTexCoord2i(1,0); glVertex3i(20,20,0 )
    glTexCoord2i(1,1); glVertex3i(20,20,20)
    glTexCoord2i(0,1); glVertex3i(0 ,20,20)

    glTexCoord2i(0,0); glVertex3i(0 ,0 ,0 )
    glTexCoord2i(1,0); glVertex3i(0 ,0 ,20)
    glTexCoord2i(1,1); glVertex3i(0 ,20,20)
    glTexCoord2i(0,1); glVertex3i(0 ,20,0 )

    glTexCoord2i(0,0); glVertex3i(20,0 ,0 )
    glTexCoord2i(1,0); glVertex3i(20,0 ,20)
    glTexCoord2i(1,1); glVertex3i(20,20,20)
    glTexCoord2i(0,1); glVertex3i(20,20,0 )

    glTexCoord2i(0,0); glVertex3i(0 ,0 ,0 )
    glTexCoord2i(1,0); glVertex3i(20,0 ,0 )
    glTexCoord2i(1,1); glVertex3i(20,20,0 )
    glTexCoord2i(0,1); glVertex3i(0 ,20,0 )

    glTexCoord2i(0,0); glVertex3i(0 ,0 ,20)
    glTexCoord2i(1,0); glVertex3i(20,0 ,20)
    glTexCoord2i(1,1); glVertex3i(20,20,20)
    glTexCoord2i(0,1); glVertex3i(0 ,20,20)
    glEnd()
    glDisable(GL_TEXTURE_2D)
    glEndList()

    dlFakeShadow = glGenLists(1)
    glNewList(dlFakeShadow, GL_COMPILE)
    glEnable(GL_TEXTURE_2D)
    glBindTexture(GL_TEXTURE_2D, textures[1])
    glBegin(GL_QUADS)
    glTexCoord2i(0,0); glVertex3i(-1, 0,-1)
    glTexCoord2i(1,0); glVertex3i( 1, 0,-1)
    glTexCoord2i(1,1); glVertex3i( 1, 0, 1)
    glTexCoord2i(0,1); glVertex3i(-1, 0, 1)
    glEnd()
    glDisable(GL_TEXTURE_2D)
    glEndList()

    dlSpheres = []
    for list in range(15):
        dlSpheres.append(glGenLists(1))
    for Sphere in range(15):
        glNewList(dlSpheres[Sphere], GL_COMPILE)
        glEnable(GL_TEXTURE_2D)
        glBindTexture(GL_TEXTURE_2D, textures[2+Sphere])
        Sphere = gluNewQuadric()
        gluQuadricTexture(Sphere, GL_TRUE)
        gluSphere(Sphere, 1, 20, 20)
        glDisable(GL_TEXTURE_2D)
        glEndList()

    return [dlWorld, dlSpheres, dlFakeShadow]
